Data Collection 
