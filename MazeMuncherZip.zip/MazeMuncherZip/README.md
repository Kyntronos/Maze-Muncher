# Maze-Muncher
CSCI441VA-Software Engineering Project - A pac-man style like game creating using Javascript utilizing new ideas and possible mechanics that expand on the simple and fun game of pac-man
