Maze muncher and Phaser.io require a web server to run. 
We are currently using a local server such as Live Server ,which is a VS code extension, to run our game.
Once you Live Server installed in VS Code, you can navigate to MainMenu.html and right-click > open with Live Server.
