Integration testing
npm install --save-dev puppeteer
npm test
